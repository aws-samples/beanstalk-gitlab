#!/bin/bash
S3_BUCKET_NAME=$(/opt/elasticbeanstalk/bin/get-config environment -k AWS_S3_BUCKET_VALUE)
echo "copying myca.crt file from s3 bucket."
echo "Bucket name exported from the environment variable that was set in the Beanstalk environment configuration through Cloudforamtion script :::: ${S3_BUCKET_NAME}"
#- Namespace: "aws:elasticbeanstalk:application:environment"
#          OptionName: AWS_S3_BUCKET_VALUE
#          Value:
#            Fn::ImportValue: "exp-s3-bucket"

sudo mkdir -p /etc/docker/certs.d
sudo aws s3 cp s3://${S3_BUCKET_NAME}/myca.crt /etc/docker/certs.d/ca.crt
sudo cp -r -p /etc/docker/certs.d/ca.crt /etc/pki/tls/certs/
ls -ltra /etc/docker/certs.d/ca.crt
ls -ltra /etc/pki/tls/certs/ca.crt
sudo service docker stop
sudo service docker start
sudo service docker status