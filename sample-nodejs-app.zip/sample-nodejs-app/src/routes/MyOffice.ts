import {Request, Response} from "express"
import emps = require("../database/mydb.json");


export class MyOffice {
    public routes(myapp): void {
        myapp.route('/')
            .get((req:Request, res: Response) => {
                    res.setHeader('Content-Type', 'text/html')
                    var someHTML = "<!DOCTYPE html> \
                    <html> \
                        <body> \
                        <header> \
                          <h1>Deploying a NodeJS application using Amazon Elastic Beanstalk and GitLab CI/CD</h1> \
                          <p>AWS blog by Drew Dennis and Srikanth Kodali</p> \
                          <h3>You can also try other application URLs: '/emps', '/emps/2' and /health</h3> \
                        </header> \
                        </body> \
                    </html>"
                    res.status(200).send(someHTML)
                }
            )
        myapp.route('/health')
            .get((req:Request, res: Response) => {
                res.setHeader('Content-Type', 'text/html')
                var someHTML = "<!DOCTYPE html> \
                <html> \
                    <body> \
                    <header> \
                      <h1>Application health is good</h1> \
                      <p>AWS blog by Drew Dennis and Srikanth Kodali</p> \
                      <h3>You can also try other application URLs: '/emps', '/emps/2' and /health</h3> \
                    </header> \
                    </body> \
                </html>"
                res.status(200).send(someHTML)
                }
            )
        myapp.route('/emps')
            .get((req: Request, res: Response) => {
                    res.status(200).send(emps);
                }
            )

        myapp.route('/emps/:id')
            .get((req: Request, res: Response) => {
                    let id = req.params.id;
                    res.status(200).send(emps[id]);
                }
            )

    }
}