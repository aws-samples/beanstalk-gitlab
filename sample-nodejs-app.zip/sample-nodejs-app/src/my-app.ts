import * as express from 'express';
import * as bodyParser from 'body-parser';
import { MyOffice } from "./routes/MyOffice";

class MyApp {
    public myapp: express.Application;
    public myemps: MyOffice = new MyOffice();

    constructor() {
        this.myapp = express();
        this.exec();
        this.myemps.routes(this.myapp);
    }

    private exec(): void {
        this.myapp.use(bodyParser.json());
        this.myapp.use(bodyParser.urlencoded(
            {
                extended: false
            }
        ))
    }
}

export default new MyApp().myapp