import myapp from "./my-app"
const port = process.env.PORT || 80;

myapp.listen(port, () => {
        console.log("My app port number is : " + port);
    }
)

const yoyo = (person) => {
    return "hello, " + person;
}

let user = "AWS"
console.log(yoyo(user));